PATH="../../.atelierTmp.txt"

# Read current working directory from state file (if exists)
if [ -f "$PATH" ]; then
    IFS= read -r CWD < "$PATH"
else
    CWD=""
fi

# If no args: list subdirectories (numbered) and exit
if [ $# -eq 0 ]; then
    i=1
    for dir in "$CWD"/*/; do
      if [ -d "$dir" ]; then 
        name="${dir%/}"
        name="${name##*/}"
        echo "$i $name"
        ((i++))
      fi
    done
    exit 0
fi

dirs=()

ARG="$1"

if [[ "$ARG" =~ ^[0-9]+$ ]]; then
  for dir in "$CWD"/*/; do
    if [ -d "$dir" ];then
      name="${dir%/}"
      dirs+=("${name##*/}")
    fi
  done

  if [ "$ARG" -lt 1 ] || [ "$ARG" -gt "${#dirs[@]}" ]; then
    echo "Ցուցիչը պանակների քանակից մեծ է. Ընտրիր 1-${#dirs[@]}"
    exit 1
  fi

  SELECTED="${dirs[$((ARG-1))]}"
  echo "$SELECTED"
  echo "$CWD/$SELECTED" > "$PATH"

  exit 0
fi

TARGET="$CWD/$ARG"

if [ -d "$TARGET" ];then 
  echo $TARGET > $PATH
  echo "Changed to: $TARGET"
else 
  echo "Այսպսիսի պանակ չկա։ $TARGET"
  exit 1
fi
